const form = document.getElementById("form");
const email = document.getElementById("email");
const password = document.getElementById("password");

form.addEventListener('submit', e => {
    e.preventDefault();
    checkInput();
});

function checkInput() {
    const emailValue = email.value.trim();
    const passwordValue = password.value.trim();
    

//EMAIL.
    if(emailValue === '') {
        setError(email, 'Email Cannot Be Blank');
    }
    else if(emailValue !== 'hello@outlook.com') {
        setError(email, 'Email not registered')
    }
    else{
        setSuccess(email);
    }


//PASSWORD.
if(passwordValue === '') {
        setError(password, 'Password Cannot Be Blank');
    }
    else if(passwordValue !== '1234') {
        setError(password, 'Password not a Match')
    }
    else{
        setSuccess(password);
    }


//Bootstrap font/icons.
    function setError(input, message) {
        const formControl = input.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = 'form-control error';
        small.innerText = message;
    }

    function setSuccess(input){
        const formControl = input.parentElement;
        formControl.className = 'form-control success';
    }
}