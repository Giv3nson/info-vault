const form = document.getElementById("form");
const username = document.getElementById("username");
const email = document.getElementById("email");
const password = document.getElementById("password");
const password2 = document.getElementById("password2");

form.addEventListener('submit', e => {
    e.preventDefault();
    checkInput();
});

function checkInput() {
    const usernameValue = username.value.trim();
    const emailValue = email.value.trim();
    const passwordValue = password.value.trim();
    const password2Value = password2.value.trim();
    

//USERNAME.
    if(usernameValue === '') {
        setError(username, 'Username Cannot Be Blank');
    }
    else if(usernameValue !== 'Kitty') {
        setError(username, 'Name already registered')
    }
    else {
        setSuccess(username);
    }


//EMAIL.
    if(emailValue === '') {
        setError(email, 'Email Cannot Be Blank');
    }
    else if(emailValue == 'hello@outlook.com') {
        setError(email, 'Email already registered')
    }
    else{
        setSuccess(email);
    }


//PASSWORD.
if(passwordValue === '') {
        setError(password, 'Password Cannot Be Blank');
    }
    else{
        setSuccess(password);
    }

//CONFIRM PASSWORD.
if(password2Value === '') {
    setError(password2, 'Confirm Password Here');
}
else if(passwordValue !== password2Value) {
    setError(password2, 'Password Does Not Match')
}
else{
    setSuccess(password2);
}
}


//Bootstrap font/icons.
    function setError(input, message) {
        const formControl = input.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = 'form-control error';
        small.innerText = message;
    }

    function setSuccess(input){
        const formControl = input.parentElement;
        formControl.className = 'form-control success';
    }
