    const form = document.getElementById("form");
    const username = document.getElementById("username");
    const age = document.getElementById("age");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const password2 = document.getElementById("password2");

    form.addEventListener('submit', e => {
        e.preventDefault();
        checkInput();
    });

    function checkInput() {
        const usernameValue = username.value.trim();
        const ageValue = age.value.trim();
        const emailValue = email.value.trim();
        const passwordValue = password.value.trim();
        const password2Value = password2.value.trim();

//USERNAME.
        if(usernameValue === '') {
            setError(username, 'Username Cannot Be Blank');
        }
        else {
            setSuccess(username);
        }
        
//AGE.
        if(ageValue >= 0 && ageValue < 18)  {
            setError(age, 'You Shall Not Pass!');
           
        }
        else if(ageValue >= 31 && ageValue <= 90) {
            setError(age, "Shouldn't You Be Sleeping!")
        }
        
        else{
            setSuccess(age);
        }
        

//EMAIL.
        if(emailValue === '') {
            setError(email, 'Email Cannot Be Blank');
        }
        else if(isEmail(emailValue)) {
            setError(email, 'Not a valid Email')
        }
        else {
            setSuccess(email);
        }
    

//PASSWORD.
    if(passwordValue === '') {
            setError(password, 'Password Cannot Be Blank');
        }
        else{
            setSuccess(password);
        }

//CONFIRM PASSWORD.
        if(password2Value === '') {
            setError(password2, 'Confirm Password Here');
        }
        else if(passwordValue !== password2Value) {
            setError(password2, 'Password Does Not Match')
        }
        else{
            setSuccess(password2);
        }
    }

//Bootstrap font/icons.
        function setError(input, message) {
            const formControl = input.parentElement;
            const small = formControl.querySelector('small');
            formControl.className = 'form-control error';
            small.innerText = message;
        }

        function setSuccess(input){
            const formControl = input.parentElement;
            formControl.className = 'form-control success';
        }


    function isEmail(email) {
        return
    }